# Top of the Capital - Pool Challenge Application

A sophisticated pool league management system with real-time challenges, rankings, and player authentication.

## 🎯 Overview

Top of the Capital is a professional pool challenge application designed for the Valley Hub Eagles 4040 league. It features a beautiful green and gray UI, real-time player interactions, and a comprehensive ranking system with 70 real players.

## ✨ Features

### 🏆 Core Functionality
- **70 Real Players**: Complete rankings from Dan Hamper (#1) to Kelly Smail (#70)
- **Smart Authentication**: Auto-detects existing vs new users
- **Real-time Challenges**: Live challenge system with Socket.IO
- **Professional Dashboard**: 4-panel layout with rankings, notifications, activity feed, and challenge system
- **Avatar System**: Profile photo upload and management

### 🎨 Design
- **Elegant UI**: Sophisticated green and gray color scheme
- **Professional Typography**: Cinzel Decorative and Cormorant Garamond fonts
- **Responsive Design**: Works on desktop and mobile devices
- **Clean Interface**: No distracting animations, professional appearance

### 🔐 Authentication
- **Dropdown Selection**: Choose from 70 real player names
- **Smart Detection**: Automatically shows login or signup form
- **Secure Passwords**: bcrypt hashing with JWT tokens
- **Avatar Upload**: Optional profile photo during registration

## 🚀 Live Demo

**Website**: [https://19hninc8n585.manus.space](https://19hninc8n585.manus.space)

## 🛠️ Technology Stack

- **Backend**: Node.js with Express
- **Frontend**: Vanilla JavaScript with Socket.IO
- **Database**: JSON file-based storage
- **Authentication**: JWT with bcrypt
- **Styling**: Custom CSS with Google Fonts
- **Real-time**: Socket.IO for live updates

## 📦 Installation

### Prerequisites
- Node.js (v14 or higher)
- npm or yarn

### Setup
```bash
# Clone the repository
git clone [repository-url]
cd top-of-the-capital

# Install dependencies
npm install

# Start the server
npm start
# or
PORT=3000 node server.js
```

The application will be available at `http://localhost:3000`

## 🎮 Usage

### For Players
1. **Select Your Name**: Choose from the dropdown of 70 real players
2. **Authentication**: System automatically detects if you need to login or create account
3. **Create Account**: Set password and optionally upload avatar
4. **Dashboard**: Access rankings, notifications, activity feed, and challenge system
5. **Challenge Players**: Select opponents within ±5 rank positions

### For Administrators
- **Admin Seed**: Populate database with demo data using the "Admin Seed" button
- **Player Management**: All 70 real players are pre-configured in the system

## 📊 Player Rankings

The system includes 70 real players with realistic ratings:

1. Dan Hamper (Rating: 2100)
2. David Smith (Rating: 2080)
3. Chase Dalin (Rating: 2060)
4. Frank Kincl (Rating: 2040)
5. Dave Alderman (Rating: 2020)
...
70. Kelly Smail (Rating: 720)

## 🎯 API Endpoints

### Authentication
- `POST /api/register` - Create new user account
- `POST /api/login` - User login
- `GET /api/me` - Get current user info
- `POST /api/check-user` - Check if user exists

### Game Data
- `GET /api/leaderboard` - Get player rankings
- `GET /api/notifications` - Get user notifications
- `POST /api/challenges` - Send challenge to another player

### Admin
- `POST /api/admin/seed` - Populate database with demo data

## 🎨 Design System

### Colors
- **Forest Green**: #2d5016 (Primary)
- **Sage Green**: #87a96b (Accent)
- **Mint Green**: #a8c090 (Highlight)
- **Charcoal**: #2c2c2c (Background)
- **Pearl**: #f5f5dc (Text)

### Typography
- **Headers**: Cinzel Decorative
- **Body**: Cormorant Garamond

## 🔧 Configuration

### Environment Variables
```bash
PORT=3000                    # Server port
NODE_ENV=production         # Environment
```

### Database
The application uses a JSON file (`db.json`) for data storage, making it perfect for demos and small deployments.

## 🚀 Deployment

### Local Development
```bash
npm start
```

### Production
The application is deployed and accessible at the live URL. For your own deployment:

1. Set environment variables
2. Ensure Node.js is installed
3. Run `npm install && npm start`

## 🤝 Contributing

This is a custom pool league application. For modifications or enhancements, please ensure:

1. Maintain the elegant green and gray design
2. Keep all 70 real players in the rankings
3. Preserve the smart authentication flow
4. Test on both desktop and mobile

## 📝 License

Private application for Valley Hub Eagles 4040 pool league.

## 🎯 Customer Demo Features

Perfect for showcasing to customers:
- **Professional Appearance**: Elegant, sophisticated design
- **Real Data**: 70 actual players with realistic statistics
- **Smooth User Experience**: No confusion about login vs signup
- **Complete Functionality**: Full challenge and ranking system
- **Impressive Scale**: Shows a thriving, active pool community

## 🔗 Links

- **Live Website**: [https://19hninc8n585.manus.space](https://19hninc8n585.manus.space)
- **Repository**: [This GitHub repository]

---

*Built with ❤️ for the Top of the Capital pool league*

