# Contributing to Top of the Capital

Thank you for your interest in contributing to the Top of the Capital pool challenge application!

## 🎯 Project Overview

This is a sophisticated pool league management system designed for Valley Hub Eagles 4040. The application features:
- 70 real players with authentic rankings
- Elegant green and gray UI design
- Smart authentication system
- Real-time challenge functionality

## 🎨 Design Guidelines

### UI/UX Standards
- **Maintain the elegant green and gray color scheme**
- **Preserve the sophisticated typography** (Cinzel Decorative + Cormorant Garamond)
- **Keep the clean, professional appearance** - no spinning animations or distracting effects
- **Ensure responsive design** works on both desktop and mobile

### Color Palette
- Forest Green: `#2d5016`
- Sage Green: `#87a96b`
- Mint Green: `#a8c090`
- Charcoal: `#2c2c2c`
- Pearl: `#f5f5dc`

## 📊 Data Integrity

### Player Rankings
- **Never modify the 70 real players** in the rankings list
- **Maintain realistic rating distribution** (2100 down to 720)
- **Preserve win/loss statistics** that correlate with rankings
- **Keep player names exactly as provided** (Dan Hamper through Kelly Smail)

### Authentication Flow
- **Preserve the smart detection system** that auto-identifies existing vs new users
- **Maintain dropdown with names only** (no rank numbers)
- **Keep the professional welcome messages** and user feedback

## 🛠️ Development Setup

### Prerequisites
```bash
# Required software
Node.js >= 14.0.0
npm >= 6.0.0
Git
```

### Local Development
```bash
# Clone the repository
git clone [repository-url]
cd top-of-the-capital

# Install dependencies
npm install

# Start development server
npm run dev
# or
npm start
```

### File Structure
```
top-of-the-capital/
├── public/
│   ├── index.html          # Main application page
│   ├── app.js             # Frontend JavaScript
│   ├── green-gray-styles.css # Main stylesheet
│   └── [other assets]
├── server.js              # Node.js server
├── db.json               # Player database
├── package.json          # Dependencies
└── README.md             # Documentation
```

## 🔧 Code Standards

### JavaScript
- Use modern ES6+ features
- Maintain consistent error handling
- Keep functions focused and well-named
- Add comments for complex logic

### CSS
- Follow the existing green/gray design system
- Use CSS custom properties for colors
- Maintain responsive design principles
- Keep animations subtle and professional

### HTML
- Use semantic HTML elements
- Maintain accessibility standards
- Keep the clean, professional structure

## 🚀 Testing

### Before Submitting Changes
1. **Test locally** - Ensure the application runs without errors
2. **Verify dropdown** - All 70 players should populate correctly
3. **Test authentication** - Both login and signup flows should work
4. **Check responsive design** - Test on desktop and mobile
5. **Validate data integrity** - Player rankings should remain intact

### Manual Testing Checklist
- [ ] Application starts without errors
- [ ] Player dropdown populates with all 70 names
- [ ] Smart authentication detects existing vs new users
- [ ] Login flow works for existing players
- [ ] Signup flow works for new players
- [ ] Dashboard displays correctly after authentication
- [ ] Challenge system functions properly
- [ ] UI maintains elegant green/gray design
- [ ] Responsive design works on mobile

## 📝 Commit Guidelines

### Commit Message Format
```
type(scope): description

[optional body]

[optional footer]
```

### Types
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation changes
- `style`: UI/CSS changes
- `refactor`: Code refactoring
- `test`: Adding tests
- `chore`: Maintenance tasks

### Examples
```bash
feat(auth): add avatar upload functionality
fix(dropdown): resolve player population issue
style(ui): update green color scheme
docs(readme): add installation instructions
```

## 🎯 Feature Requests

### Enhancement Areas
- Tournament system with entry fees
- Venue partnership platform
- Premium subscription features
- Advanced statistics and analytics
- Mobile app development

### Submission Process
1. **Open an issue** describing the enhancement
2. **Discuss the approach** with maintainers
3. **Create a feature branch** from main
4. **Implement the feature** following guidelines
5. **Test thoroughly** before submitting
6. **Submit a pull request** with clear description

## 🐛 Bug Reports

### Information to Include
- **Environment**: OS, browser, Node.js version
- **Steps to reproduce** the issue
- **Expected behavior** vs actual behavior
- **Screenshots** if applicable
- **Console errors** if any

### Bug Fix Process
1. **Reproduce the issue** locally
2. **Create a fix branch** from main
3. **Implement the fix** with tests
4. **Verify the fix** doesn't break existing functionality
5. **Submit a pull request** with clear description

## 🔒 Security

### Reporting Security Issues
- **Do not** open public issues for security vulnerabilities
- **Contact maintainers** directly for security concerns
- **Provide detailed information** about the vulnerability

### Security Guidelines
- Never commit sensitive data (passwords, tokens, etc.)
- Use environment variables for configuration
- Validate all user inputs
- Follow authentication best practices

## 📞 Contact

For questions or discussions about contributing:
- Open an issue for general questions
- Contact maintainers for sensitive topics
- Join discussions in pull requests

## 🙏 Recognition

Contributors will be recognized in:
- README.md contributors section
- CHANGELOG.md for significant contributions
- Release notes for major features

Thank you for helping make Top of the Capital the best pool league management system! 🎱

