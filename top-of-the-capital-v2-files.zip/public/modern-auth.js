// Modern Authentication JavaScript
class ModernAuth {
    constructor() {
        this.currentStep = 1;
        this.selectedPlayer = null;
        this.playerData = null;
        this.init();
    }

    init() {
        this.loadPlayers();
        this.setupEventListeners();
    }

    setupEventListeners() {
        // Player selection
        document.getElementById('playerName').addEventListener('change', this.handlePlayerSelection.bind(this));
        
        // Continue button
        document.getElementById('continueBtn').addEventListener('click', this.handleContinue.bind(this));
        
        // Login button
        document.getElementById('loginBtn').addEventListener('click', this.handleLogin.bind(this));
        
        // Signup button
        document.getElementById('signupBtn').addEventListener('click', this.handleSignup.bind(this));
        
        // Avatar upload
        document.getElementById('uploadAvatarBtn').addEventListener('click', () => {
            document.getElementById('avatarUpload').click();
        });
        
        document.getElementById('avatarUpload').addEventListener('change', this.handleAvatarUpload.bind(this));
        
        document.getElementById('removeAvatarBtn').addEventListener('click', this.removeAvatar.bind(this));
        
        // Admin seed
        document.getElementById('adminSeedBtn').addEventListener('click', this.handleAdminSeed.bind(this));
        
        // Enter key handling
        document.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                if (this.currentStep === 1 && !document.getElementById('continueBtn').disabled) {
                    this.handleContinue();
                } else if (this.currentStep === 2) {
                    const loginStep = document.getElementById('step2Login');
                    const signupStep = document.getElementById('step2Signup');
                    
                    if (!loginStep.classList.contains('hidden')) {
                        this.handleLogin();
                    } else if (!signupStep.classList.contains('hidden')) {
                        this.handleSignup();
                    }
                }
            }
        });
    }

    async loadPlayers() {
        try {
            const response = await fetch('/api/leaderboard');
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const players = await response.json();
            const select = document.getElementById('playerName');
            
            // Clear existing options except the first one
            while (select.children.length > 1) {
                select.removeChild(select.lastChild);
            }
            
            // Add all players
            players.forEach(player => {
                const option = document.createElement('option');
                option.value = player.name;
                option.textContent = player.name;
                select.appendChild(option);
            });
            
            console.log(`Loaded ${players.length} players`);
        } catch (error) {
            console.error('Failed to load players:', error);
            this.showError('Failed to load player list. Please refresh the page.');
        }
    }

    handlePlayerSelection() {
        const select = document.getElementById('playerName');
        const continueBtn = document.getElementById('continueBtn');
        
        if (select.value) {
            this.selectedPlayer = select.value;
            continueBtn.disabled = false;
        } else {
            this.selectedPlayer = null;
            continueBtn.disabled = true;
        }
    }

    async handleContinue() {
        if (!this.selectedPlayer) return;
        
        this.showLoading('loadingStep1', true);
        
        try {
            // Check if user exists
            const response = await fetch('/api/check-user', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ playerName: this.selectedPlayer })
            });
            
            const result = await response.json();
            
            if (result.exists) {
                this.showLoginStep(result);
            } else {
                this.showSignupStep();
            }
        } catch (error) {
            console.error('Error checking user:', error);
            this.showError('Unable to verify account. Please try again.');
        } finally {
            this.showLoading('loadingStep1', false);
        }
    }

    showLoginStep(userData) {
        this.playerData = userData;
        this.currentStep = 2;
        
        // Update UI
        document.getElementById('userInitials').textContent = this.getInitials(userData.displayName);
        document.getElementById('welcomeBackMessage').textContent = `Welcome back, ${userData.displayName}!`;
        document.getElementById('userDetails').textContent = `Rating: ${userData.rating} • Returning Player`;
        
        // Show login step
        this.hideAllSteps();
        document.getElementById('step2Login').classList.add('active');
        
        // Focus password field
        setTimeout(() => {
            document.getElementById('loginPassword').focus();
        }, 100);
    }

    showSignupStep() {
        this.currentStep = 2;
        
        // Update UI
        document.getElementById('newUserInitials').textContent = this.getInitials(this.selectedPlayer);
        document.getElementById('createAccountMessage').textContent = `Welcome, ${this.selectedPlayer}!`;
        document.getElementById('newUserDetails').textContent = 'New Player • Create your account to join';
        
        // Show signup step
        this.hideAllSteps();
        document.getElementById('step2Signup').classList.add('active');
        
        // Focus password field
        setTimeout(() => {
            document.getElementById('signupPassword').focus();
        }, 100);
    }

    async handleLogin() {
        const password = document.getElementById('loginPassword').value;
        
        if (!password) {
            this.showError('Please enter your password.');
            return;
        }
        
        this.showLoading('loadingLogin', true);
        
        try {
            const email = this.generateEmail(this.selectedPlayer);
            
            const response = await fetch('/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });
            
            const data = await response.json();
            
            if (response.ok) {
                localStorage.setItem('token', data.token);
                this.showSuccess();
            } else {
                this.showError(data.message || 'Invalid password. Please try again.');
            }
        } catch (error) {
            console.error('Login error:', error);
            this.showError('Login failed. Please try again.');
        } finally {
            this.showLoading('loadingLogin', false);
        }
    }

    async handleSignup() {
        const password = document.getElementById('signupPassword').value;
        
        if (!password) {
            this.showError('Please create a password.');
            return;
        }
        
        if (password.length < 6) {
            this.showError('Password must be at least 6 characters long.');
            return;
        }
        
        this.showLoading('loadingSignup', true);
        
        try {
            const email = this.generateEmail(this.selectedPlayer);
            
            const response = await fetch('/api/auth/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    email, 
                    password,
                    displayName: this.selectedPlayer
                })
            });
            
            const data = await response.json();
            
            if (response.ok) {
                localStorage.setItem('token', data.token);
                
                // Upload avatar if selected
                const avatarPreview = document.getElementById('avatarPreview');
                if (!avatarPreview.classList.contains('hidden')) {
                    await this.uploadAvatar();
                }
                
                this.showSuccess();
            } else {
                this.showError(data.message || 'Account creation failed. Please try again.');
            }
        } catch (error) {
            console.error('Signup error:', error);
            this.showError('Account creation failed. Please try again.');
        } finally {
            this.showLoading('loadingSignup', false);
        }
    }

    handleAvatarUpload(event) {
        const file = event.target.files[0];
        if (!file) return;
        
        // Validate file
        if (!file.type.startsWith('image/')) {
            this.showError('Please select an image file.');
            return;
        }
        
        if (file.size > 5 * 1024 * 1024) {
            this.showError('Image must be smaller than 5MB.');
            return;
        }
        
        // Show preview
        const reader = new FileReader();
        reader.onload = (e) => {
            const preview = document.getElementById('avatarPreview');
            const img = document.getElementById('previewImg');
            
            img.src = e.target.result;
            preview.classList.remove('hidden');
        };
        reader.readAsDataURL(file);
    }

    removeAvatar() {
        const preview = document.getElementById('avatarPreview');
        const upload = document.getElementById('avatarUpload');
        
        preview.classList.add('hidden');
        upload.value = '';
    }

    async uploadAvatar() {
        const img = document.getElementById('previewImg');
        if (!img.src) return;
        
        try {
            const response = await fetch('/api/avatar/upload', {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                },
                body: JSON.stringify({ avatarData: img.src })
            });
            
            if (!response.ok) {
                console.error('Avatar upload failed');
            }
        } catch (error) {
            console.error('Avatar upload error:', error);
        }
    }

    async handleAdminSeed() {
        try {
            const response = await fetch('/api/admin/seed', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' }
            });
            
            if (response.ok) {
                this.showSuccess('Demo data seeded successfully!');
                // Reload players
                setTimeout(() => {
                    this.loadPlayers();
                }, 1000);
            } else {
                this.showError('Failed to seed demo data.');
            }
        } catch (error) {
            console.error('Admin seed error:', error);
            this.showError('Failed to seed demo data.');
        }
    }

    showSuccess(message = null) {
        this.hideAllSteps();
        document.getElementById('stepSuccess').classList.add('active');
        
        // After success, show dashboard instead of redirecting
        setTimeout(() => {
            this.showDashboard();
        }, 2000);
        
        if (message) {
            const successDiv = document.createElement('div');
            successDiv.className = 'success-message';
            successDiv.textContent = message;
            document.querySelector('.auth-card').appendChild(successDiv);
            
            setTimeout(() => {
                successDiv.remove();
            }, 3000);
        }
    }

    showDashboard() {
        // Hide auth view
        document.getElementById('authView').classList.add('hidden');
        
        // Show dashboard view
        document.getElementById('dashboardView').classList.add('active');
        
        // Initialize dashboard if app.js is loaded
        if (window.initializeDashboard) {
            window.initializeDashboard();
        }
    }

    showError(message) {
        // Remove existing error messages
        const existingErrors = document.querySelectorAll('.error-message');
        existingErrors.forEach(error => error.remove());
        
        // Show new error
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-message';
        errorDiv.textContent = message;
        
        const activeStep = document.querySelector('.auth-step.active');
        activeStep.appendChild(errorDiv);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            errorDiv.remove();
        }, 5000);
    }

    showLoading(elementId, show) {
        const element = document.getElementById(elementId);
        if (show) {
            element.classList.remove('hidden');
        } else {
            element.classList.add('hidden');
        }
    }

    hideAllSteps() {
        const steps = document.querySelectorAll('.auth-step');
        steps.forEach(step => {
            step.classList.remove('active');
            step.classList.add('hidden');
        });
    }

    getInitials(name) {
        return name.split(' ').map(word => word[0]).join('').toUpperCase().slice(0, 2);
    }

    generateEmail(playerName) {
        return playerName.toLowerCase().replace(/\s+/g, '.') + '@topofthecapital.local';
    }
}

// Back to step 1 function (global for onclick)
function goBackToStep1() {
    const auth = window.modernAuth;
    auth.currentStep = 1;
    auth.selectedPlayer = null;
    
    // Reset form
    document.getElementById('playerName').value = '';
    document.getElementById('continueBtn').disabled = true;
    document.getElementById('loginPassword').value = '';
    document.getElementById('signupPassword').value = '';
    
    // Remove any error messages
    const errors = document.querySelectorAll('.error-message');
    errors.forEach(error => error.remove());
    
    // Show step 1
    auth.hideAllSteps();
    document.getElementById('step1').classList.add('active');
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', () => {
    window.modernAuth = new ModernAuth();
});

