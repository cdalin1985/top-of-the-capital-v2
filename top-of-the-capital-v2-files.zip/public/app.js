// Pool Challenge - Frontend JavaScript
let socket;
let currentUser = null;
let leaderboardData = [];

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    console.log('App loaded');
    
    // Initialize Socket.IO
    socket = io();
    
    // Populate player dropdown immediately
    populatePlayerDropdown();
    
    // Set up event listeners
    setupEventListeners();
    
    // Check if user is already logged in
    const token = localStorage.getItem('token');
    if (token) {
        // Validate token and show dashboard if valid
        validateTokenAndShowDashboard(token);
    }
});

// Populate the player dropdown with all players from leaderboard
async function populatePlayerDropdown() {
    try {
        console.log('Fetching players for dropdown...');
        
        // First try to get leaderboard data
        const response = await fetch('/api/leaderboard');
        
        if (response.ok) {
            const players = await response.json();
            console.log('Loaded players:', players.length);
            
            const select = document.getElementById('playerSelect');
            if (!select) {
                console.error('Player select element not found');
                return;
            }
            
            // Clear existing options except the first one
            while (select.children.length > 1) {
                select.removeChild(select.lastChild);
            }
            
            // Add all players to dropdown (names only, no rank numbers)
            players.forEach(player => {
                const option = document.createElement('option');
                option.value = player.name;
                option.textContent = player.name;
                select.appendChild(option);
            });
            
            console.log('Player dropdown populated with', players.length, 'players');
        } else {
            console.error('Failed to fetch players:', response.status, response.statusText);
            
            // If leaderboard fails, try to seed data first
            console.log('Attempting to seed data...');
            await seedDemoData();
            
            // Try again after seeding
            setTimeout(() => {
                populatePlayerDropdown();
            }, 1000);
        }
    } catch (error) {
        console.error('Error populating player dropdown:', error);
        
        // Try to seed data if there's an error
        try {
            await seedDemoData();
            setTimeout(() => {
                populatePlayerDropdown();
            }, 1000);
        } catch (seedError) {
            console.error('Failed to seed data:', seedError);
        }
    }
}

// Seed demo data
async function seedDemoData() {
    try {
        const response = await fetch('/api/admin/seed', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ secret: 'please_change_admin_secret' })
        });
        
        if (response.ok) {
            console.log('Demo data seeded successfully');
            return true;
        } else {
            console.error('Failed to seed demo data');
            return false;
        }
    } catch (error) {
        console.error('Seed error:', error);
        return false;
    }
}

// Handle player selection from dropdown
async function handlePlayerSelection() {
    const select = document.getElementById('playerSelect');
    const selectedPlayer = select.value;
    
    if (!selectedPlayer) {
        // Clear dynamic content if no player selected
        document.getElementById('dynamicAuthContent').innerHTML = '';
        return;
    }
    
    console.log('Player selected:', selectedPlayer);
    
    try {
        // Check if user exists
        const response = await fetch('/api/check-user', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ playerName: selectedPlayer })
        });
        
        const result = await response.json();
        
        if (result.exists) {
            // Show login form for existing user
            showLoginForm(selectedPlayer, result);
        } else {
            // Show signup form for new user
            showSignupForm(selectedPlayer);
        }
    } catch (error) {
        console.error('Error checking user:', error);
        // Default to signup form if check fails
        showSignupForm(selectedPlayer);
    }
}

// Show login form for existing user
function showLoginForm(playerName, userInfo) {
    const dynamicContent = document.getElementById('dynamicAuthContent');
    
    dynamicContent.innerHTML = `
        <div style="margin-bottom: 15px; padding: 15px; background: rgba(135, 169, 107, 0.1); border: 1px solid var(--sage-green); border-radius: 8px;">
            <h4 style="color: var(--sage-green); margin: 0 0 5px 0;">Welcome back, ${playerName}!</h4>
            <p style="margin: 0; color: var(--pearl); font-size: 14px;">Rating: ${userInfo.rating || 1000}</p>
        </div>
        
        <div style="margin-bottom: 15px;">
            <label style="display: block; margin-bottom: 5px; color: var(--sage-green); font-weight: 600;">Password</label>
            <input type="password" id="loginPassword" class="auth-input" placeholder="Enter your password" style="width: 100%;">
        </div>
        
        <div style="margin-bottom: 15px;">
            <button id="btnLogin" class="btn btn-primary" onclick="performLogin('${playerName}')">Login</button>
        </div>
    `;
}

// Show signup form for new user
function showSignupForm(playerName) {
    const dynamicContent = document.getElementById('dynamicAuthContent');
    
    dynamicContent.innerHTML = `
        <div style="margin-bottom: 15px; padding: 15px; background: rgba(135, 169, 107, 0.1); border: 1px solid var(--sage-green); border-radius: 8px;">
            <h4 style="color: var(--sage-green); margin: 0 0 5px 0;">Welcome, ${playerName}!</h4>
            <p style="margin: 0; color: var(--pearl); font-size: 14px;">Let's create your account</p>
        </div>
        
        <div style="margin-bottom: 15px;">
            <label style="display: block; margin-bottom: 5px; color: var(--sage-green); font-weight: 600;">Create Password</label>
            <input type="password" id="signupPassword" class="auth-input" placeholder="Create a secure password" style="width: 100%;">
        </div>
        
        <div style="margin-bottom: 15px;">
            <label style="display: block; margin-bottom: 5px; color: var(--sage-green); font-weight: 600;">Avatar (Optional)</label>
            <input type="file" id="avatarUpload" accept="image/*" class="auth-input" style="width: 100%;">
        </div>
        
        <div style="margin-bottom: 15px;">
            <button id="btnSignup" class="btn btn-primary" onclick="performSignup('${playerName}')">Create Account</button>
        </div>
    `;
}

// Perform login
async function performLogin(playerName) {
    const password = document.getElementById('loginPassword').value;
    
    if (!password) {
        showAuthMessage('Please enter your password', 'error');
        return;
    }
    
    try {
        const email = playerName.toLowerCase().replace(/\s+/g, '.') + '@topofthecapital.local';
        
        const response = await fetch('/api/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                email: email,
                password: password
            })
        });
        
        const result = await response.json();
        
        if (response.ok) {
            localStorage.setItem('token', result.token);
            showAuthMessage('Login successful!', 'success');
            setTimeout(() => {
                showDashboard();
            }, 1000);
        } else {
            showAuthMessage(result.message || 'Login failed', 'error');
        }
    } catch (error) {
        console.error('Login error:', error);
        showAuthMessage('Login failed. Please try again.', 'error');
    }
}

// Perform signup
async function performSignup(playerName) {
    const password = document.getElementById('signupPassword').value;
    
    if (!password) {
        showAuthMessage('Please create a password', 'error');
        return;
    }
    
    if (password.length < 6) {
        showAuthMessage('Password must be at least 6 characters', 'error');
        return;
    }
    
    try {
        const email = playerName.toLowerCase().replace(/\s+/g, '.') + '@topofthecapital.local';
        
        const response = await fetch('/api/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                email: email,
                password: password,
                displayName: playerName
            })
        });
        
        const result = await response.json();
        
        if (response.ok) {
            localStorage.setItem('token', result.token);
            
            // Handle avatar upload if provided
            const avatarFile = document.getElementById('avatarUpload').files[0];
            if (avatarFile) {
                await uploadAvatar(avatarFile);
            }
            
            showAuthMessage('Account created successfully!', 'success');
            setTimeout(() => {
                showDashboard();
            }, 1000);
        } else {
            showAuthMessage(result.message || 'Account creation failed', 'error');
        }
    } catch (error) {
        console.error('Signup error:', error);
        showAuthMessage('Account creation failed. Please try again.', 'error');
    }
}

// Upload avatar
async function uploadAvatar(file) {
    try {
        const formData = new FormData();
        formData.append('avatar', file);
        
        const response = await fetch('/api/avatar', {
            method: 'POST',
            headers: {
                'Authorization': 'Bearer ' + localStorage.getItem('token')
            },
            body: formData
        });
        
        if (!response.ok) {
            console.error('Avatar upload failed');
        }
    } catch (error) {
        console.error('Avatar upload error:', error);
    }
}

// Show authentication message
function showAuthMessage(message, type) {
    const msgElement = document.getElementById('authMsg');
    msgElement.textContent = message;
    msgElement.className = `auth-message ${type}`;
    
    // Clear message after 5 seconds
    setTimeout(() => {
        msgElement.textContent = '';
        msgElement.className = 'auth-message';
    }, 5000);
}

// Validate token and show dashboard
async function validateTokenAndShowDashboard(token) {
    try {
        const response = await fetch('/api/me', {
            headers: {
                'Authorization': 'Bearer ' + token
            }
        });
        
        if (response.ok) {
            const user = await response.json();
            currentUser = user;
            showDashboard();
        } else {
            // Invalid token, remove it
            localStorage.removeItem('token');
        }
    } catch (error) {
        console.error('Token validation error:', error);
        localStorage.removeItem('token');
    }
}

// Show dashboard
function showDashboard() {
    document.getElementById('authSection').classList.add('hidden');
    document.getElementById('appArea').classList.remove('hidden');
    document.getElementById('userBox').classList.remove('hidden');
    
    // Initialize dashboard
    initializeDashboard();
}

// Initialize dashboard
async function initializeDashboard() {
    try {
        // Get current user info
        const token = localStorage.getItem('token');
        const response = await fetch('/api/me', {
            headers: {
                'Authorization': 'Bearer ' + token
            }
        });
        
        if (response.ok) {
            currentUser = await response.json();
            
            // Update user info
            document.getElementById('userName').textContent = currentUser.displayName || currentUser.email;
            document.getElementById('userStatus').textContent = `Rating: ${currentUser.rating || 1000}`;
            
            // Load dashboard data
            loadLeaderboard();
            loadNotifications();
            loadCommunityFeed();
            setupChallengeSystem();
            
            // Join socket room
            socket.emit('join', { userId: currentUser.id });
        }
    } catch (error) {
        console.error('Dashboard initialization error:', error);
    }
}

// Load leaderboard
async function loadLeaderboard() {
    try {
        const token = localStorage.getItem('token');
        const response = await fetch('/api/leaderboard', {
            headers: {
                'Authorization': 'Bearer ' + token
            }
        });
        
        if (response.ok) {
            leaderboardData = await response.json();
            displayLeaderboard();
        }
    } catch (error) {
        console.error('Error loading leaderboard:', error);
    }
}

// Display leaderboard
function displayLeaderboard() {
    const container = document.getElementById('leaderboard');
    
    if (leaderboardData.length === 0) {
        container.innerHTML = '<div class="empty-state">No players found</div>';
        return;
    }
    
    let html = '';
    leaderboardData.forEach((player, index) => {
        const isCurrentUser = currentUser && player.id === currentUser.id;
        const userIndicator = isCurrentUser ? ' [YOU]' : '';
        
        html += `
            <div class="ranking-item ${isCurrentUser ? 'current-user' : ''}" onclick="selectChallengeTarget('${player.id}', '${player.name}', ${player.rank})">
                <span class="rank">${player.rank}</span>
                <span class="name">${player.name}${userIndicator}</span>
                <span class="rating">${player.rating}</span>
                <span class="record">${player.wins}W-${player.losses}L</span>
                ${!isCurrentUser ? '<span class="challenge-btn">⚔️</span>' : ''}
            </div>
        `;
    });
    
    container.innerHTML = html;
}

// Load notifications
async function loadNotifications() {
    try {
        const token = localStorage.getItem('token');
        const response = await fetch('/api/notifications', {
            headers: {
                'Authorization': 'Bearer ' + token
            }
        });
        
        if (response.ok) {
            const notifications = await response.json();
            displayNotifications(notifications);
        }
    } catch (error) {
        console.error('Error loading notifications:', error);
    }
}

// Display notifications
function displayNotifications(notifications) {
    const container = document.getElementById('notifications');
    
    if (notifications.length === 0) {
        container.innerHTML = '<div class="empty-state">No new correspondence</div>';
        return;
    }
    
    let html = '';
    notifications.forEach(notification => {
        html += `
            <div class="notification-item">
                <div class="notification-message">${notification.message}</div>
                <div class="notification-time">${new Date(notification.createdAt).toLocaleString()}</div>
            </div>
        `;
    });
    
    container.innerHTML = html;
}

// Load community feed
async function loadCommunityFeed() {
    try {
        const token = localStorage.getItem('token');
        const response = await fetch('/api/notifications', {
            headers: {
                'Authorization': 'Bearer ' + token
            }
        });
        
        if (response.ok) {
            const feed = await response.json();
            displayCommunityFeed(feed);
        }
    } catch (error) {
        console.error('Error loading community feed:', error);
    }
}

// Display community feed
function displayCommunityFeed(feed) {
    const container = document.getElementById('feed');
    
    if (feed.length === 0) {
        container.innerHTML = '<div class="empty-state">League activity will appear here</div>';
        return;
    }
    
    let html = '';
    feed.slice(0, 10).forEach(item => {
        html += `
            <div class="feed-item">
                <div class="feed-message">${item.message}</div>
                <div class="feed-time">${new Date(item.createdAt).toLocaleString()}</div>
            </div>
        `;
    });
    
    container.innerHTML = html;
}

// Setup challenge system
function setupChallengeSystem() {
    // Update user profile in challenge system
    document.getElementById('myName').textContent = currentUser.displayName || currentUser.email;
    document.getElementById('myRating').textContent = `Rating: ${currentUser.rating || 1000}`;
    document.getElementById('myStats').textContent = `Record: ${currentUser.stats?.wins || 0}W-${currentUser.stats?.losses || 0}L`;
}

// Select challenge target
function selectChallengeTarget(targetId, targetName, targetRank) {
    if (!currentUser) return;
    
    const currentRank = leaderboardData.find(p => p.id === currentUser.id)?.rank || 999;
    const rankDifference = Math.abs(currentRank - targetRank);
    
    if (rankDifference > 5) {
        showAuthMessage(`You can only challenge players within ±5 ranks of your position`, 'error');
        return;
    }
    
    // Show target selection
    document.getElementById('selectedTarget').classList.remove('hidden');
    document.getElementById('targetInfo').innerHTML = `
        <h4>Challenge Target Selected</h4>
        <p><strong>${targetName}</strong> (Rank #${targetRank})</p>
    `;
    
    // Store target info for challenge submission
    window.selectedTarget = { id: targetId, name: targetName, rank: targetRank };
}

// Setup event listeners
function setupEventListeners() {
    // Admin seed button
    document.getElementById('btnSeed').addEventListener('click', async function() {
        try {
            const response = await fetch('/api/admin/seed', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ secret: 'please_change_admin_secret' })
            });
            
            if (response.ok) {
                showAuthMessage('Demo data seeded successfully!', 'success');
                // Refresh player dropdown
                populatePlayerDropdown();
            } else {
                showAuthMessage('Failed to seed demo data', 'error');
            }
        } catch (error) {
            console.error('Seed error:', error);
            showAuthMessage('Failed to seed demo data', 'error');
        }
    });
    
    // Logout button
    document.getElementById('btnLogout').addEventListener('click', function() {
        localStorage.removeItem('token');
        currentUser = null;
        
        // Hide dashboard and show auth
        document.getElementById('appArea').classList.add('hidden');
        document.getElementById('userBox').classList.add('hidden');
        document.getElementById('authSection').classList.remove('hidden');
        
        // Clear dynamic content
        document.getElementById('dynamicAuthContent').innerHTML = '';
        document.getElementById('playerSelect').value = '';
        
        showAuthMessage('Logged out successfully', 'success');
    });
    
    // Send challenge button
    document.getElementById('sendChallenge').addEventListener('click', async function() {
        if (!window.selectedTarget) {
            showAuthMessage('Please select a target first', 'error');
            return;
        }
        
        const discipline = document.getElementById('discipline').value;
        const gamesToWin = document.getElementById('gamesToWin').value;
        
        try {
            const token = localStorage.getItem('token');
            const response = await fetch('/api/challenges', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + token
                },
                body: JSON.stringify({
                    targetUserId: window.selectedTarget.id,
                    discipline: discipline,
                    gamesToWin: parseInt(gamesToWin)
                })
            });
            
            if (response.ok) {
                showAuthMessage(`Challenge sent to ${window.selectedTarget.name}!`, 'success');
                
                // Hide target selection
                document.getElementById('selectedTarget').classList.add('hidden');
                window.selectedTarget = null;
                
                // Refresh notifications
                loadNotifications();
                loadCommunityFeed();
            } else {
                const error = await response.json();
                showAuthMessage(error.message || 'Failed to send challenge', 'error');
            }
        } catch (error) {
            console.error('Challenge error:', error);
            showAuthMessage('Failed to send challenge', 'error');
        }
    });
    
    // Cancel target button
    document.getElementById('cancelTarget').addEventListener('click', function() {
        document.getElementById('selectedTarget').classList.add('hidden');
        window.selectedTarget = null;
    });
}

// Socket event listeners
socket.on('notification', function(notification) {
    // Refresh notifications when new ones arrive
    loadNotifications();
    loadCommunityFeed();
});

// Make functions globally available
window.handlePlayerSelection = handlePlayerSelection;
window.performLogin = performLogin;
window.performSignup = performSignup;
window.selectChallengeTarget = selectChallengeTarget;

