/**
 * Pool Challenge - Hybrid (Option 3)
 * Simple Express + file-based JSON DB + Socket.IO real-time notifications
 * Admin panel available at /admin.html (protected by admin secret)
 *
 * ENV:
 *  - PORT (optional)
 *  - JWT_SECRET (recommended)
 *  - ADMIN_SECRET (recommended -- used to create admin user via the /api/admin/seed endpoint)
 */

const express = require('express');
const http = require('http');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { Server } = require('socket.io');

require('dotenv').config();
const JWT_SECRET = process.env.JWT_SECRET || 'dev_jwt_secret_change_me';
const ADMIN_SECRET = process.env.ADMIN_SECRET || 'please_change_admin_secret';

const DB_FILE = path.join(__dirname, 'db.json');
if (!fs.existsSync(DB_FILE)) {
  fs.writeFileSync(DB_FILE, JSON.stringify({
    users: [],
    challenges: [],
    notifications: []
  }, null, 2));
}
function readDB(){ return JSON.parse(fs.readFileSync(DB_FILE)); }
function writeDB(db){ fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2)); }

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Check if user exists endpoint for modern auth flow
app.post('/api/check-user', (req, res) => {
  try {
    const { playerName } = req.body;
    if (!playerName) {
      return res.status(400).json({ error: 'Player name is required' });
    }

    const db = readDB();
    const email = playerName.toLowerCase().replace(/\s+/g, '.') + '@topofthecapital.local';
    const user = db.users.find(u => u.email === email);

    if (user) {
      res.json({
        exists: true,
        displayName: user.displayName,
        rating: user.rating || 1000,
        avatar: user.avatar || null
      });
    } else {
      res.json({ exists: false });
    }
  } catch (error) {
    console.error('Check user error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// --- Socket.IO: simple rooms per user and 'community' room
io.on('connection', (socket) => {
  console.log('Socket connected', socket.id);
  socket.on('join', (payload) => {
    if (payload && payload.userId) {
      socket.join('user:' + payload.userId);
    }
    socket.join('community');
  });
});

// --- Auth helpers
function signToken(userId){ return jwt.sign({ userId }, JWT_SECRET, { expiresIn: '7d' }); }
function authMiddleware(req, res, next){
  const header = req.headers.authorization || '';
  const token = header.replace('Bearer ', '');
  if (!token) return res.status(401).json({ message: 'Missing token' });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.userId = payload.userId;
    next();
  } catch(e){ return res.status(401).json({ message: 'Invalid token' }); }
}

// --- API: Auth
app.post('/api/auth/register', async (req, res) => {
  try {
    const { email, password, displayName, chooseFromList } = req.body;
    if (!email || !password) return res.status(400).json({ message: 'Email and password required' });
    const db = readDB();
    if (db.users.find(u => u.email.toLowerCase() === email.toLowerCase())) {
      return res.status(409).json({ message: 'Email already in use' });
    }
    const hash = await bcrypt.hash(password, 10);
    const user = {
      id: Date.now().toString(),
      email,
      password: hash,
      displayName: displayName || '',
      avatar: null,
      rating: 1500,
      stats: { wins:0, losses:0 },
      isAdmin: false,
      createdAt: new Date().toISOString()
    };
    db.users.push(user); writeDB(db);
    const token = signToken(user.id);
    res.status(201).json({ user: { id: user.id, email: user.email, displayName: user.displayName, rating: user.rating }, token });
  } catch(e){ console.error(e); res.status(500).json({ message: 'Server error' }); }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const db = readDB();
    const user = db.users.find(u => u.email.toLowerCase() === (email||'').toLowerCase());
    if (!user) return res.status(401).json({ message: 'Invalid credentials' });
    const ok = await bcrypt.compare(password, user.password);
    if (!ok) return res.status(401).json({ message: 'Invalid credentials' });
    const token = signToken(user.id);
    res.json({ user: { id: user.id, email: user.email, displayName: user.displayName, rating: user.rating }, token });
  } catch(e){ console.error(e); res.status(500).json({ message: 'Login error' }); }
});

// --- API: Avatar Management
app.post('/api/avatar/upload', authMiddleware, (req, res) => {
  try {
    const { avatarData } = req.body;
    if (!avatarData) return res.status(400).json({ message: 'Avatar data required' });
    
    const db = readDB();
    const user = db.users.find(u => u.id === req.userId);
    if (!user) return res.status(404).json({ message: 'User not found' });
    
    user.avatar = avatarData;
    writeDB(db);
    
    res.json({ message: 'Avatar uploaded successfully', avatar: avatarData });
  } catch(e) {
    console.error(e);
    res.status(500).json({ message: 'Avatar upload error' });
  }
});

app.delete('/api/avatar', authMiddleware, (req, res) => {
  try {
    const db = readDB();
    const user = db.users.find(u => u.id === req.userId);
    if (!user) return res.status(404).json({ message: 'User not found' });
    
    user.avatar = null;
    writeDB(db);
    
    res.json({ message: 'Avatar deleted successfully' });
  } catch(e) {
    console.error(e);
    res.status(500).json({ message: 'Avatar delete error' });
  }
});

// --- API: Check if user exists (for smart login flow)
app.post('/api/check-user', (req, res) => {
  try {
    const { playerName } = req.body;
    if (!playerName) return res.status(400).json({ message: 'Player name required' });
    
    const db = readDB();
    const user = db.users.find(u => u.displayName === playerName);
    
    if (user) {
      res.json({ 
        exists: true, 
        hasAvatar: !!user.avatar,
        displayName: user.displayName,
        rating: user.rating 
      });
    } else {
      res.json({ exists: false });
    }
  } catch(e) { 
    console.error(e); 
    res.status(500).json({ message: 'Server error' }); 
  }
});

// --- API: Users & Leaderboard
app.get('/api/users', authMiddleware, (req, res) => {
  const db = readDB();
  const users = db.users.map(u => ({ id:u.id, displayName:u.displayName, email:u.email, rating:u.rating, avatar:u.avatar, stats:u.stats }));
  res.json(users);
});

app.get('/api/leaderboard', (req, res) => {
  const db = readDB();
  const sorted = db.users.slice().sort((a,b)=>b.rating - a.rating);
  const leaderboard = sorted.map((u, index) => ({ 
    id: u.id, 
    name: u.displayName || u.email, 
    email: u.email,
    rating: u.rating, 
    wins: u.stats?.wins || 0,
    losses: u.stats?.losses || 0,
    rank: index + 1,
    avatar: u.avatar 
  }));
  res.json(leaderboard);
});

// --- API: Challenges
app.post('/api/challenges', authMiddleware, (req, res) => {
  const { targetUserId, discipline, gamesToWin } = req.body;
  if (!targetUserId || !discipline || !gamesToWin) return res.status(400).json({ message: 'Missing fields' });
  if (Number(gamesToWin) < 5) return res.status(400).json({ message: 'Games to win must be at least 5' });
  const db = readDB();
  const challenger = db.users.find(u=>u.id===req.userId);
  const target = db.users.find(u=>u.id===targetUserId);
  if (!challenger || !target) return res.status(404).json({ message: 'User not found' });
  const ch = {
    id: Date.now().toString(),
    creatorId: req.userId,
    creatorName: challenger.displayName || challenger.email,
    targetUserId,
    targetName: target.displayName || target.email,
    discipline,
    gamesToWin: Number(gamesToWin),
    status: 'pending',
    createdAt: new Date().toISOString(),
    venue: null,
    scheduledAt: null,
    messages: []
  };
  db.challenges.push(ch); writeDB(db);
  const notification = { id: Date.now().toString(), type:'challenge', challengeId: ch.id, to: targetUserId, from: req.userId, message: `${ch.creatorName} challenged ${ch.targetName} (${discipline}, first to ${gamesToWin})`, createdAt: new Date().toISOString() };
  db.notifications.push(notification); writeDB(db);
  io.to('user:'+targetUserId).emit('notification', notification);
  io.to('community').emit('notification', notification);
  res.status(201).json(ch);
});

// Opponent picks venue & datetime to propose
app.post('/api/challenges/:id/propose', authMiddleware, (req, res) => {
  const { id } = req.params;
  const { venue, scheduledAt } = req.body;
  const db = readDB();
  const ch = db.challenges.find(c => c.id === id);
  if (!ch) return res.status(404).json({ message: 'Challenge not found' });
  if (ch.targetUserId !== req.userId) return res.status(403).json({ message: 'Not authorized' });
  ch.venue = venue;
  ch.scheduledAt = scheduledAt;
  ch.status = 'proposed';
  ch.updatedAt = new Date().toISOString();
  writeDB(db);
  const n = { id: Date.now().toString(), type:'proposal', challengeId: ch.id, to: ch.creatorId, from: req.userId, message: `${ch.targetName} proposed ${venue} at ${scheduledAt}`, createdAt: new Date().toISOString() };
  db.notifications.push(n); writeDB(db);
  io.to('user:'+ch.creatorId).emit('notification', n);
  io.to('community').emit('notification', n);
  res.json(ch);
});

// Creator confirms or suggests new time (confirm endpoint)
app.post('/api/challenges/:id/confirm', authMiddleware, (req, res) => {
  const { id } = req.params;
  const db = readDB();
  const ch = db.challenges.find(c => c.id === id);
  if (!ch) return res.status(404).json({ message: 'Challenge not found' });
  if (ch.creatorId !== req.userId) return res.status(403).json({ message: 'Not authorized' });
  ch.status = 'scheduled';
  ch.confirmedAt = new Date().toISOString();
  writeDB(db);
  const n = { id: Date.now().toString(), type:'confirmed', challengeId: ch.id, to: ch.targetUserId, from: req.userId, message: `${ch.creatorName} confirmed ${ch.venue} at ${ch.scheduledAt}`, createdAt: new Date().toISOString() };
  db.notifications.push(n); writeDB(db);
  io.to('user:'+ch.targetUserId).emit('notification', n);
  io.to('community').emit('notification', n);
  res.json(ch);
});

// List challenges (open to authenticated)
app.get('/api/challenges', authMiddleware, (req,res)=>{
  const db = readDB();
  res.json(db.challenges);
});

// Notifications
app.get('/api/notifications', authMiddleware, (req,res)=>{
  const db = readDB();
  const mine = db.notifications.filter(n => n.to === req.userId || n.to === 'community');
  res.json(mine.slice(-50).reverse());
});

// --- Admin endpoints (protected by ADMIN_SECRET header for seeding / admin creation)
app.post('/api/admin/seed', (req,res)=>{
  const { secret } = req.body;
  if (secret !== ADMIN_SECRET) return res.status(403).json({ message: 'Bad admin secret' });
  const db = readDB();
  if (!db.users.find(u=>u.email==='valley@example.com')) {
    db.users.push({ id:'u1', email:'valley@example.com', password: 'x', displayName:'ValleyPlayer', avatar:null, rating:1600, stats:{wins:10,losses:2}, isAdmin:false, createdAt:new Date().toISOString() });
  }
  if (!db.users.find(u=>u.email==='eagle@example.com')) {
    db.users.push({ id:'u2', email:'eagle@example.com', password: 'x', displayName:'EaglePlayer', avatar:null, rating:1580, stats:{wins:8,losses:5}, isAdmin:false, createdAt:new Date().toISOString() });
  }
  if (!db.users.find(u=>u.email==='admin@pool.local')) {
    const hash = bcrypt.hashSync('adminpass', 10);
    db.users.push({ id:'admin', email:'admin@pool.local', password: hash, displayName:'Admin', avatar:null, rating:2000, stats:{wins:0,losses:0}, isAdmin:true, createdAt:new Date().toISOString() });
  }
  writeDB(db);
  res.json({ ok:true });
});

// Serve static admin and app files via public directory
app.get('*', (req,res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, ()=>console.log('Pool Challenge hybrid server listening on', PORT));
